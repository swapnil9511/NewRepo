package com.project.vims;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VimsApplication {

	public static void main(String[] args) {
		SpringApplication.run(VimsApplication.class, args);
		System.out.println("VIMS");
	}

}

//JSON according to pojo
//{
//		"claimId" : "1",
//		"claimAmount": 15000.75,
//		"claimDate": "2025-10-14",
//		"claimStatus": "REJECTED",
//		"adjuster": {
//		"userId": 2
//		},
//		"policy": {
//		"policyId": 2
//		}
//		}


//Dependencies of Module (Mapping) : user,vehicle , policy , claim(curd operations)
//
