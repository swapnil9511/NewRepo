package com.project.vims.support.repo;


import com.project.vims.support.entity.SupportTicket;

import com.project.vims.user.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SupportRepo extends JpaRepository<SupportTicket,Long> {

    //custom Method
    public List<SupportTicket> findByUser(User user);

}
