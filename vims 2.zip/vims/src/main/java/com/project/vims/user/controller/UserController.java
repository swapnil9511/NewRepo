package com.project.vims.user.controller;

import com.project.vims.user.entity.User;
import com.project.vims.user.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@RequestMapping("/api/user")
public class UserController {

    private static final Logger log = LoggerFactory.getLogger(UserController.class);

    @Autowired
    UserService userService;

    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody User user) {
        log.info("API call received: POST /api/user/register for username: {}", user.getUsername());
        try {
            User registeredUser = userService.registerUser(user);
            log.info("Response: 201 CREATED for user ID: {}", registeredUser.getUserId());
            return new ResponseEntity<>(registeredUser, HttpStatus.CREATED);
        } catch (Exception e) {
            log.error("Response: 409 CONFLICT during registration. Error: {}", e.getMessage());
            return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT);
        }
    }

    @PostMapping("/login")
    public ResponseEntity<?> loginUser(@RequestBody User user) {
        log.info("API call received: POST /api/user/login for username: {}", user.getUsername());
        try {
            User loggedInUser = userService.loginUser(user.getUsername(), user.getPassword());
            log.info("Response: 200 OK. Successful login for user: {}", loggedInUser.getUsername());
            // Return the entire user object including role
            return new ResponseEntity<>(loggedInUser, HttpStatus.OK);
        } catch (Exception e) {
            log.error("Response: 401 UNAUTHORIZED during login. Error: {}", e.getMessage());
            return new ResponseEntity<>(e.getMessage(), HttpStatus.UNAUTHORIZED);
        }
    }

    @GetMapping("/{userId}")
    public ResponseEntity<User> getUserById(@PathVariable Long userId) {
        log.info("API call received: GET /api/user/{}", userId);
        try {
            User user = userService.getUserById(userId);
            if (user == null) {
                log.info("Response: 404 NOT FOUND for user ID: {}", userId);
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
            log.info("Response: 200 OK for user ID: {}", userId);
            return ResponseEntity.ok(user);
        } catch (Exception e) {
            log.error("Response: 500 INTERNAL SERVER ERROR while fetching user ID {}. Error: {}", userId, e.getMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // 💡 NEW ENDPOINT: Get user role by ID for frontend checks
    @GetMapping("/role/{userId}")
    public ResponseEntity<?> getUserRole(@PathVariable Long userId) {
        log.info("API call received: GET /api/user/role/{}", userId);
        try {
            User user = userService.getUserById(userId);
            if (user == null) {
                log.info("Response: 404 NOT FOUND for user ID: {}", userId);
                return new ResponseEntity<>("User not found", HttpStatus.NOT_FOUND);
            }
            // Return only the role name
            log.info("Response: 200 OK. Role found for user ID {}: {}", userId, user.getRole());
            return ResponseEntity.ok(user.getRole().name());
        } catch (Exception e) {
            log.error("Response: 500 INTERNAL SERVER ERROR while fetching role for ID {}. Error: {}", userId, e.getMessage());
            return new ResponseEntity<>("Failed to fetch role", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/logout/{userId}")
    public ResponseEntity<String> logOutUser(@PathVariable Long userId) {
        log.info("API call received: POST /api/user/logout/{}", userId);
        String message = userService.logOutUser(userId);
        log.info("Response: 200 OK. Logout message: {}", message);
        return ResponseEntity.ok(message);
    }

    @PutMapping("/update/{userId}")
    public ResponseEntity<?> updateUser(@PathVariable Long userId, @RequestBody User user) {
        log.info("API call received: PUT /api/user/update/{} for username: {}", userId, user.getUsername());
        try {
            User updatedUser = userService.updateUser(userId, user);
            log.info("Response: 200 OK. Successfully updated user ID: {}", updatedUser.getUserId());
            return new ResponseEntity<>(updatedUser, HttpStatus.OK);
        } catch (RuntimeException e) {
            log.error("Response: 409 CONFLICT/404 NOT FOUND during update for ID {}. Error: {}", userId, e.getMessage());
            return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT);
        } catch (Exception e) {
            log.error("Response: 500 INTERNAL SERVER ERROR during update for ID {}. Error: {}", userId, e.getMessage());
            return new ResponseEntity<>("Failed to update profile due to an internal error.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}