package com.project.vims.claims.service;

import com.project.vims.claims.entity.Claims;
import com.project.vims.claims.repo.ClaimsRepo;
import com.project.vims.policy.entity.Policy;
import com.project.vims.policy.repo.PolicyRepo;
import com.project.vims.user.entity.User;
import com.project.vims.user.repo.UserRepo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class ClaimsService {

    private static final Logger logger = LoggerFactory.getLogger(ClaimsService.class);

    @Autowired
    ClaimsRepo claimsRepo;

    @Autowired
    PolicyRepo policyRepo;

    @Autowired
    UserRepo userRepo;

    public ResponseEntity<Map<String,Object>> submitClaim(Claims claims){

        logger.info("Attempting to submit a new claim...");

        Map<String, Object> map = new HashMap<>();

        if (claims == null || claims.getPolicy() == null || claims.getPolicy().getPolicyId() == null) {
            logger.warn("Validation failed : Claim Data or Policy data missing");
            map.put("message", "Invalid claim data provided. Policy information is missing.");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(map);
        }

        Optional<Policy> policyDB = policyRepo.findById(claims.getPolicy().getPolicyId());
        if (policyDB.isEmpty()) {
            logger.warn("Validation failed : Policy ID is not found");
            map.put("message", "Policy with ID " + claims.getPolicy().getPolicyId() + " not found.");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(map);
        }

        claims.setPolicy(policyDB.get());
        claims.setClaimStatus(Claims.ClaimStatus.PENDING);
        Claims savedClaim = claimsRepo.save(claims);
        logger.info("Successfully submitted claim with ID: {}" ,savedClaim.getClaimId());

        map.put("message", "Claim submitted successfully");
        map.put("data", savedClaim);

        return ResponseEntity.status(HttpStatus.CREATED).body(map);
    }

    public ResponseEntity<Map<String,Object>> getClaimDetails(Long claimId){

        logger.info("Attempting to get details for claim ID: {}", claimId);

        Map<String,Object> map = new HashMap<String,Object>();
        Optional<Claims> claimDB = claimsRepo.findById(claimId);

        if (claimDB.isEmpty()) {
            logger.warn("Claim with ID {} not found.", claimId);
            map.put("message", "Claim with ID " + claimId + " not found.");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(map);
        }

        logger.info("Successfully retrieved details for claim ID: {}", claimId);

        map.put("message", "Claim details retrieved successfully");
        map.put("data", claimDB.get());
        return ResponseEntity.status(HttpStatus.OK).body(map);

    }

    public ResponseEntity<Map<String,Object>> updateClaimStatus(Claims claims){

        logger.info("Attempting to update status for claim ID: {}", claims != null ? claims.getClaimId() : "null");
        Map<String,Object> map = new HashMap<String,Object>();

        // --- START: Logic from your example ---

        // 0. Extract Acting User ID from the 'adjuster' field of the incoming request
        Long actingUserId = null;
        if (claims != null && claims.getAdjuster() != null && claims.getAdjuster().getUserId() != null) {
            actingUserId = claims.getAdjuster().getUserId();
        }

        if (actingUserId == null) {
            map.put("message","Authentication failed: User ID not provided.");
            logger.warn("Authentication failed: actingUserId was null.");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(map);
        }

        // 1. Check if the User exists and retrieve their role
        Optional<User> actingUserOpt = userRepo.findById(actingUserId);
        if(actingUserOpt.isEmpty()){
            map.put("message","Authentication failed: User not found.");
            logger.warn("Authentication failed: User ID " + actingUserId + " not found.");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(map);
        }

        User actingUser = actingUserOpt.get();

        // 2. Role-Based Access Check: Only CLAIM_ADJUSTER can update
        // (Using 'User.Role.CLAIM_ADJUSTER' from your User entity)
        if (actingUser.getRole() != User.Role.CLAIM_ADJUSTER) {
            map.put("message","Access Denied. Only users with the CLAIM_ADJUSTER role can update status.");
            logger.warn("Access Denied: User " + actingUserId + " with role " + actingUser.getRole() + " attempted to update claim " + (claims != null ? claims.getClaimId() : "N/A"));
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(map); // HTTP 403 Forbidden
        }

        // --- END: Logic from your example ---

        // 3. Original logic (if role check passes)
        if(claims.getClaimId()==null) {
            logger.warn("Validation failed: Invalid data provided for claim update (Claim ID is null).");
            map.put("message","Invalid data. Claim ID is missing.");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(map);
        }

        Optional<Claims> claimDB = claimsRepo.findById(claims.getClaimId());
        if(claimDB.isEmpty()){
            logger.warn("Cannot update status. Claim with ID {} not found.", claims.getClaimId());
            map.put("message","Claim with ID " + claims.getClaimId() + " not found");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(map);
        }

        Claims existingClaim = claimDB.get();
        existingClaim.setClaimStatus(claims.getClaimStatus());

        // --- IMPORTANT: Set the adjuster to the user who performed the update ---
        existingClaim.setAdjuster(actingUser);

        Claims updatedClaim = claimsRepo.save(existingClaim);
        logger.info("Successfully updated status for claim ID: {}", updatedClaim.getClaimId());

        map.put("message","Updated successfully");
        map.put("data",updatedClaim);
        return ResponseEntity.status(HttpStatus.OK).body(map);
    }

//    public ResponseEntity<Map<String,Object>> updateClaimStatus(Claims claims){
//
//
//        logger.info("Attempting to update status for claim ID: {}", claims != null ? claims.getClaimId() : "null");
//
//        Map<String,Object> map = new HashMap<String,Object>();
//
//        if(claims==null || claims.getClaimId()==null) {
//            logger.warn("Validation failed: Invalid data provided for claim update.");
//            map.put("message","Invalid data");
//            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(map);
//        }
//
//        Optional<Claims> claimDB = claimsRepo.findById(claims.getClaimId());
//        if(claimDB.isEmpty()){
//            logger.warn("Cannot update status. Claim with ID {} not found.", claims.getClaimId());
//            map.put("message","Claim with ID" + claims.getClaimId() + " not found");
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(map);
//        }
//
//        Claims existingClaim = claimDB.get();
//        existingClaim.setClaimStatus(claims.getClaimStatus());
//        Claims updatedClaim = claimsRepo.save(existingClaim);
//        logger.info("Successfully updated status for claim ID: {}", updatedClaim.getClaimId());
//
//        map.put("message","Updated successfully");
//        map.put("data",updatedClaim);
//        return ResponseEntity.status(HttpStatus.OK).body(map);
//    }



    public ResponseEntity<Map<String,Object>> getAllClaimsByPolicy(Long policy_id){

        logger.info("Attempting to get all claims for policy ID: {}", policy_id);

        Map<String,Object> map = new HashMap<>();
        Optional<Policy> policyDB = policyRepo.findById(policy_id);


        if(policyDB.isEmpty()){
            logger.warn("Cannot get claims. Policy with ID {} not found.", policy_id);
            map.put("message","Policy with ID" + policy_id+" not found");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(map);
        }

        List<Claims> list = claimsRepo.findByPolicy(policyDB.get());
        logger.info("Found {} claims for policy ID: {}", list.size(), policy_id);
        map.put("message","claims retrived successfully");
        map.put("data",list);


        return ResponseEntity.status(HttpStatus.OK).body(map);

    }
}
