package com.project.vims.vehicle.entity;

import com.project.vims.user.entity.User;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "vehicle")
public class Vehicle {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long vehicleId;

    @NotBlank
    private String vehicleNumber;

    @NotBlank
    private String vehicleMake;

    @NotBlank
    private String vehicleModel;

    @NotNull
    private Integer vehicleYear;

    @ManyToOne
    @JoinColumn(name = "owner_id")
    private User owner;

    // Getters and Setters
    public Long getVehicleId() {
        return vehicleId;
    }
    public void setVehicleId(Long vehicleId) {
        this.vehicleId = vehicleId;
    }
    public String getVehicleNumber() {
        return vehicleNumber;
    }
    public void setVehicleNumber(String vehicleNumber) {
        this.vehicleNumber = vehicleNumber;
    }
    public String getVehicleMake() {
        return vehicleMake;
    }
    public void setVehicleMake(String vehicleMake) {
        this.vehicleMake = vehicleMake;
    }
    public String getVehicleModel() {
        return vehicleModel;
    }
    public void setVehicleModel(String vehicleModel) {
        this.vehicleModel = vehicleModel;
    }
    public Integer getVehicleYear() {
        return vehicleYear;
    }
    public void setVehicleYear(Integer vehicleYear) {
        this.vehicleYear = vehicleYear;
    }
    public User getOwner() {
        return owner;
    }
    public void setOwner(User owner) {
        this.owner = owner;
    }
	public Vehicle(Long vehicleId, @NotBlank String vehicleNumber, @NotBlank String vehicleMake,
			@NotBlank String vehicleModel, @NotNull Integer vehicleYear, User owner) {
		super();
		this.vehicleId = vehicleId;
		this.vehicleNumber = vehicleNumber;
		this.vehicleMake = vehicleMake;
		this.vehicleModel = vehicleModel;
		this.vehicleYear = vehicleYear;
		this.owner = owner;
	}
	
	
	public Vehicle() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Vehicle(@NotBlank String vehicleNumber, @NotBlank String vehicleMake, @NotBlank String vehicleModel,
			@NotNull Integer vehicleYear, User owner) {
		super();
		this.vehicleNumber = vehicleNumber;
		this.vehicleMake = vehicleMake;
		this.vehicleModel = vehicleModel;
		this.vehicleYear = vehicleYear;
		this.owner = owner;
	}
	@Override
	public String toString() {
		return "Vehicle [vehicleId=" + vehicleId + ", vehicleNumber=" + vehicleNumber + ", vehicleMake=" + vehicleMake
				+ ", vehicleModel=" + vehicleModel + ", vehicleYear=" + vehicleYear + ", owner=" + owner + "]";
	}
    
    
    
}