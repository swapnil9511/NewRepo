package com.project.vims.policy.repo;

import com.project.vims.policy.entity.Policy;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PolicyRepo extends JpaRepository<Policy,Long> {
    Optional<Policy> findByPolicyNumber(String policyNumber);
}
