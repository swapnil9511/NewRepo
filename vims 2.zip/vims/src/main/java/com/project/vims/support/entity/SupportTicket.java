package com.project.vims.support.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import java.time.LocalDate;

import com.project.vims.user.entity.User;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;

@Entity
@Table(name = "support_ticket")
public class SupportTicket {

    //Primary Key
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long ticketId;

    @NotNull(message = "User must be provided for a support ticket.")
    @ManyToOne
    @JoinColumn(name = "user_id")
    @JsonIgnoreProperties({"policies","handledClaims","tickets","vehicles"})
    private User user;

    @NotBlank
    @Column(length = 1000)
    private String issueDescription;

    @NotNull
    @Enumerated(EnumType.STRING)
    private TicketStatus ticketStatus = TicketStatus.OPEN;

    public enum TicketStatus {
        OPEN, RESOLVED
    }

    @NotNull
    @PastOrPresent(message = "Creation date cannot be in the future.")
    private LocalDate createdDate = LocalDate.now();

    // Getters and Setters
    public Long getTicketId() {
        return ticketId;
    }
    public void setTicketId(Long ticketId) {
        this.ticketId = ticketId;
    }
    public User getUser() {
        return user;
    }
    public void setUser(User user) {

        this.user = user;
    }
    public String getIssueDescription() {
        return issueDescription;
    }
    public void setIssueDescription(String issueDescription) {
        this.issueDescription = issueDescription;
    }
    public TicketStatus getTicketStatus() {
        return ticketStatus;
    }
    public void setTicketStatus(TicketStatus ticketStatus) {
        this.ticketStatus = ticketStatus;

    }
    public LocalDate getCreatedDate() {
        return createdDate;
    }
    public void setCreatedDate(LocalDate createdDate) {
        this.createdDate = createdDate;
    }
	public SupportTicket(Long ticketId, User user, @NotBlank String issueDescription, TicketStatus ticketStatus,
			LocalDate createdDate) {
		super();
		this.ticketId = ticketId;
		this.user = user;
		this.issueDescription = issueDescription;
		this.ticketStatus = ticketStatus;
		this.createdDate = createdDate;
	}
	public SupportTicket(User user, @NotBlank String issueDescription, TicketStatus ticketStatus,
			LocalDate createdDate) {
		super();
		this.user = user;
		this.issueDescription = issueDescription;
		this.ticketStatus = ticketStatus;
		this.createdDate = createdDate;
	}
	public SupportTicket() {
		super();
	}
	@Override
	public String toString() {
		return "SupportTicket [ticketId=" + ticketId + ", user=" + user + ", issueDescription=" + issueDescription
				+ ", ticketStatus=" + ticketStatus + ", createdDate=" + createdDate + "]";
	}
    

    
}