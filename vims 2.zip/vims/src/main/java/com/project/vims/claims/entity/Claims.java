package com.project.vims.claims.entity;



import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import java.math.BigDecimal;
import java.time.LocalDate;
import com.project.vims.policy.entity.Policy;
import com.project.vims.user.entity.User;

@Entity
@Table(name = "claim")
public class Claims {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long claimId;

    @NotNull(message = "Claim amount cannot be null.")
    @DecimalMin(value = "0.0", inclusive = false, message = "Claim amount must be greater than zero.")
    private BigDecimal claimAmount;

    @NotNull(message = "Claim date cannot be null.")
    @PastOrPresent(message = "Claim date must be in the past or present.")
    private LocalDate claimDate = LocalDate.now();

//    @NotNull(message = "Claim status cannot be null.")
    @Enumerated(EnumType.STRING)
    private ClaimStatus claimStatus;

    @NotNull
    @ManyToOne
    @JoinColumn(name = "adjuster_id")
    @JsonIgnoreProperties({"handledClaims","payments","policies","vehicles"})
    private User adjuster;

    @NotNull(message = "Claim must be associated with a policy.")
    @ManyToOne
    @JoinColumn(name = "policy_id")
    @JsonIgnoreProperties({"claims","vehicle","payments","policyholder"})
    private Policy policy;

    public enum ClaimStatus {
        PENDING, APPROVED, REJECTED
    }

    // Getters and Setters
    public Long getClaimId() {
        return claimId;
    }
    public void setClaimId(Long claimId) {
        this.claimId = claimId;
    }
    public Policy getPolicy() {
        return policy;
    }
    public void setPolicy(Policy policy) {
        this.policy = policy;
    }
    public BigDecimal getClaimAmount() {
        return claimAmount;
    }
    public void setClaimAmount(BigDecimal claimAmount) {
        this.claimAmount = claimAmount;
    }
    public LocalDate getClaimDate() {
        return claimDate;
    }
    public void setClaimDate(LocalDate claimDate) {
        this.claimDate = claimDate;
    }
    public ClaimStatus getClaimStatus() {
        return claimStatus;
    }
    public void setClaimStatus(ClaimStatus claimStatus) {
        this.claimStatus = claimStatus;
    }
    public User getAdjuster() {
        return adjuster;
    }
    public void setAdjuster(User adjuster) {
        this.adjuster = adjuster;
    }


    public Claims(Long claimId, Policy policy, @NotNull BigDecimal claimAmount, LocalDate claimDate,
                  ClaimStatus claimStatus, User adjuster) {
        super();
        this.claimId = claimId;
        this.policy = policy;
        this.claimAmount = claimAmount;
        this.claimDate = claimDate;
        this.claimStatus = claimStatus;
        this.adjuster = adjuster;
    }
    public Claims(Policy policy, @NotNull BigDecimal claimAmount, LocalDate claimDate, ClaimStatus claimStatus,
                  User adjuster) {
        super();
        this.policy = policy;
        this.claimAmount = claimAmount;
        this.claimDate = claimDate;
        this.claimStatus = claimStatus;
        this.adjuster = adjuster;
    }
    public Claims() {
        super();
        // TODO Auto-generated constructor stub
    }
    @Override
    public String toString() {
        return "Claim [claimId=" + claimId + ", policy=" + policy + ", claimAmount=" + claimAmount + ", claimDate="
                + claimDate + ", claimStatus=" + claimStatus + ", adjuster=" + adjuster + "]";
    }

}