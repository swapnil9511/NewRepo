package com.project.vims.support.controller;

import com.project.vims.support.entity.SupportTicket;
import com.project.vims.support.service.SupportService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.ErrorResponse;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/support")
public class SupportController {

    @Autowired
    SupportService supportService;


//------------------------------------------------------------------------------------------------------------------

    // create Ticket
    @PostMapping("/createTicket")
    public ResponseEntity<Map<String,Object>> createTicket(@Valid @RequestBody SupportTicket ticketData,BindingResult bindingResult){

        return supportService.createTicket(ticketData);
    }

//-------------------------------------------------------------------------------------------------------------------

    // get Ticket

    @GetMapping("/getTicket/{ticketId}")
    public ResponseEntity<Map<String,Object>> getTicketDetails(@Valid @PathVariable Long ticketId){

        return supportService.getTicketDetails(ticketId);
    }

//------------------------------------------------------------------------------------------------------------------

    //get All tickets

    @GetMapping("/getAllTickets/{userId}")
    public ResponseEntity<Map<String,Object>> getAllTicketsByUser(@Valid @PathVariable Long userId){

       return supportService.getAllTicket(userId);

    }

//----------------------------------------------------------------------------------------------------------------------

  //Resolves an Open ticket

    @PutMapping("/resolveTicket/{ticketId}")
    public ResponseEntity<Map<String,Object>> resolveTicket(@Valid @PathVariable Long ticketId,Long actingUserId){

        return supportService.resolveTicket(ticketId,actingUserId);

    }

//----------------------------------------------------------------------------------------------------------------------

    // Get All Users Tickets by Admin

    @GetMapping("/getAllTickets")
    public ResponseEntity<Map<String,Object>> getAllTicketsForAdmin(){
        return supportService.getAllTicketsForAdmin();
    }

//----------------------------------------------------------------------------------------------------------------------

}
