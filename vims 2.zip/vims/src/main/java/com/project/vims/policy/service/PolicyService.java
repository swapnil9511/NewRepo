package com.project.vims.policy.service;

import com.project.vims.policy.entity.Policy;
import com.project.vims.policy.repo.PolicyRepo;
import com.project.vims.user.entity.User;
import com.project.vims.user.entity.User.Role;
import com.project.vims.user.repo.UserRepo;
import com.project.vims.user.service.UserService;
import com.project.vims.vehicle.entity.Vehicle;
import com.project.vims.vehicle.repo.VehicleRepo;
import jakarta.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PolicyService {

    private final Logger logger = LoggerFactory.getLogger(PolicyService.class);

    @Autowired
    PolicyRepo policyRepo;
    @Autowired
    VehicleRepo vehicleRepo;
    @Autowired
    UserRepo userRepo;

    @Autowired
    UserService userService; // Inject UserService to fetch role

    // 💡 Helper method to enforce ADMIN role
    private void checkAdminRole(Long currentUserId, String action) {
        if (currentUserId == null) {
            logger.error("Authorization check failed: User ID is missing for action: {}", action);
            throw new RuntimeException("Access Denied: Authentication required. User ID is missing.");
        }

        User user = userService.getUserById(currentUserId);

        // Check if user exists and has the ADMIN role
        if (user == null || user.getRole() != Role.ADMIN) {
            logger.warn("Authorization check failed: User ID {} is not an ADMIN for action: {}", currentUserId, action);
            throw new RuntimeException("Access Denied: Only ADMIN users can " + action + " policies.");
        }
        logger.debug("Authorization check passed for User ID {} (ADMIN) for action: {}", currentUserId, action);
    }

    /** Create new Policy */
    @Transactional
    public Policy createPolicy(Long currentUserId, Long policyholderId, Long vehicleId, Policy policy) {
        // 1. 🔒 AUTHORIZATION CHECK
        checkAdminRole(currentUserId, "create");

        logger.info("Service: Starting policy creation for policyholderId: {} and vehicleId: {}", policyholderId, vehicleId);

        User policyholder = userRepo.findById(policyholderId)
                .orElseThrow(() -> {
                    logger.warn("Policyholder not found with ID: {}", policyholderId);
                    return new RuntimeException("Policyholder not found");
                });
        logger.debug("Policyholder found: {}", policyholder.getUserId());

        Vehicle vehicle = vehicleRepo.findById(vehicleId)
                .orElseThrow(() -> {
                    logger.warn("Vehicle not found with ID: {}", vehicleId);
                    return new RuntimeException("Vehicle not found");
                });
        logger.debug("Vehicle found: {}", vehicle.getVehicleId());


        // generate unique policy number
        String policyNumber = generatePolicyNumber();
        policy.setPolicyNumber(policyNumber);
        policy.setPolicyholder(policyholder);
        policy.setVehicle(vehicle);
        policy.setPolicyStatus(Policy.PolicyStatus.ACTIVE);
        logger.info("Generated policy number: {} and set status to ACTIVE.", policyNumber);

        Policy savedPolicy = policyRepo.save(policy);
        logger.info("Policy successfully saved with ID: {}", savedPolicy.getPolicyId());

        return savedPolicy;
    }

    /** Get all policies */
    public List<Policy> getAllPolicies() {
        logger.debug("Fetching all policies from repository.");
        List<Policy> policies = policyRepo.findAll();
        logger.info("Retrieved {} total policies.", policies.size());
        return policies;
    }

    /** Get single policy */
    public Policy getPolicyById(Long id) {
        logger.debug("Attempting to find policy by ID: {}", id);
        return policyRepo.findById(id)
                .orElseThrow(() -> {
                    logger.warn("Policy not found with ID: {}", id);
                    return new RuntimeException("Policy not found");
                });
    }

    /** Update existing policy */
    @Transactional
    public Policy updatePolicy(Long currentUserId, Long id, Policy updatedPolicy) {
        // 1. 🔒 AUTHORIZATION CHECK
        checkAdminRole(currentUserId, "update");

        logger.info("Starting update process for Policy ID: {}", id);
        Policy existing = policyRepo.findById(id)
                .orElseThrow(() -> {
                    logger.warn("Update failed: Policy not found with ID: {}", id);
                    return new RuntimeException("Policy not found");
                });
        logger.debug("Found existing policy with ID: {}", id);

        if(updatedPolicy.getCoverageAmount() != null){
            existing.setCoverageAmount(updatedPolicy.getCoverageAmount());
            logger.debug("Updated coverage amount for Policy ID: {}", id);
        }
        if(updatedPolicy.getPolicyStatus() != null) {
            existing.setPolicyStatus(updatedPolicy.getPolicyStatus());
            logger.info("Updated policy status for Policy ID: {} to {}", id, updatedPolicy.getPolicyStatus());
        }

        // Optionally allow vehicle or policyholder update
        if (updatedPolicy.getVehicle() != null) {
            existing.setVehicle(updatedPolicy.getVehicle());
            logger.debug("Updated vehicle for Policy ID: {}", id);
        }

        Policy savedPolicy = policyRepo.save(existing);
        logger.info("Policy ID: {} successfully saved after update.", id);
        return savedPolicy;
    }



    /** Update policy status (e.g., from INACTIVE/EXPIRED to ACTIVE) */
    @Transactional
    public Policy updatePolicyStatus(Long policyId, Policy.PolicyStatus newStatus) {
        logger.info("Updating status for Policy ID: {} to: {}", policyId, newStatus);

        Policy existingPolicy = policyRepo.findById(policyId)
                .orElseThrow(() -> {
                    logger.warn("Policy not found with ID: {}", policyId);
                    return new RuntimeException("Policy not found with ID: " + policyId);
                });

        // Only update if the new status is different
        if (existingPolicy.getPolicyStatus() != newStatus) {
            existingPolicy.setPolicyStatus(newStatus);
            logger.info("Policy ID: {} status changed from {} to {}.", policyId, existingPolicy.getPolicyStatus(), newStatus);
        } else {
            logger.debug("Policy ID: {} status is already {}. No change needed.", policyId, newStatus);
        }

        Policy savedPolicy = policyRepo.save(existingPolicy);
        logger.debug("Policy ID: {} status updated and saved.", policyId);
        return savedPolicy;
    }

    /** Delete a policy */
    @Transactional
    public void deletePolicy(Long currentUserId, Long id) {
        // 1. 🔒 AUTHORIZATION CHECK
        checkAdminRole(currentUserId, "delete");

        logger.warn("Attempting to delete policy with ID: {}", id);
        Policy policy = policyRepo.findById(id)
                .orElseThrow(() -> {
                    logger.warn("Deletion failed: Policy not found with ID: {}", id);
                    return new RuntimeException("Policy not found");
                });
        policyRepo.delete(policy);
        logger.warn("Policy ID: {} permanently deleted.", id);
    }

    // Helper method to generate unique policy number
    private String generatePolicyNumber() {
        String policyNumber = "POL-" + System.currentTimeMillis();
        logger.debug("Generated unique policy number: {}", policyNumber);
        return policyNumber;
    }
}