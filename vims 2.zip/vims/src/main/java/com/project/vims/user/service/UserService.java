package com.project.vims.user.service;

import com.project.vims.user.entity.User;
import com.project.vims.user.repo.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class UserService {

    private static final Logger log = LoggerFactory.getLogger(UserService.class);

    @Autowired
    UserRepo userRepo;

    public User registerUser(User user) {
        log.info("Attempting to register user with username: {}", user.getUsername());

        if (userRepo.findByUsername(user.getUsername()).isPresent()) {
            log.warn("Registration failed: Username {} is already taken.", user.getUsername());
            throw new RuntimeException("Username " + user.getUsername() + " is already taken.");
        }

        User savedUser = userRepo.save(user);
        log.info("Successfully registered user with ID: {}", savedUser.getUserId());
        return savedUser;
    }

    public User loginUser(String username, String password) {
        log.info("Attempting login for username: {}", username);

        Optional<User> userOptional = userRepo.findByUsername(username);

        if (userOptional.isPresent() && userOptional.get().getPassword().equals(password)) {
            log.info("Login successful for user ID: {}", userOptional.get().getUserId());
            return userOptional.get();
        }

        log.warn("Login failed for username: {}. Invalid credentials.", username);
        throw new RuntimeException("Invalid username or password.");
    }

    public String logOutUser(Long userId) {
        log.info("Processing logout for user ID: {}", userId);
        return "User with ID " + userId + " has been successfully logged out.";
    }


    public User getUserById(Long userId) {
        log.info("Fetching user details for ID: {}", userId);

        User user = userRepo.findById(userId).orElse(null);

        if (user == null) {
            log.info("User with ID {} not found.", userId);
        } else {
            log.info("User details found for ID: {}", userId);
        }

        return user;
    }

    public User updateUser(Long userId, User updatedDetails) {
        log.info("Attempting to update user ID: {}", userId);

        return userRepo.findById(userId).map(user -> {
            if (!user.getUsername().equals(updatedDetails.getUsername())) {
                if (userRepo.findByUsername(updatedDetails.getUsername()).isPresent()) {
                    log.warn("Update failed: New username {} is already taken.", updatedDetails.getUsername());
                    throw new RuntimeException("Username " + updatedDetails.getUsername() + " is already taken.");
                }
                user.setUsername(updatedDetails.getUsername());
            }

            user.setEmail(updatedDetails.getEmail());

            if (updatedDetails.getPassword() != null && !updatedDetails.getPassword().isEmpty()) {
                log.info("Updating password for user ID: {}", userId);
                user.setPassword(updatedDetails.getPassword());
            }

            User savedUser = userRepo.save(user);
            log.info("Successfully updated user ID: {}", userId);
            return savedUser;
        }).orElseThrow(() -> {
            log.error("Update failed: User ID {} not found.", userId);
            return new RuntimeException("User not found with ID: " + userId);
        });
    }


}