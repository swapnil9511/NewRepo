package com.project.vims.payment.controller;

import com.project.vims.payment.entity.Payment;
import com.project.vims.payment.entity.Payment.PaymentStatus;
import com.project.vims.payment.service.PaymentService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

// SLF4J Imports
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    // 💡 Logger for the Controller
    private static final Logger logger = LoggerFactory.getLogger(PaymentController.class);

    @Autowired
    private PaymentService paymentService;

    /**
     * POST /api/payments?policyId=123
     * Records a new payment for a policy.
     */
    @PostMapping
    public ResponseEntity<Payment> recordPayment(
            @RequestParam Long policyId,
            @Valid @RequestBody Payment payment) {

        logger.info("Attempting to record new payment for policy ID: {}", policyId);

        // Call Service
        Payment recordedPayment = paymentService.recordPayment(policyId, payment);

        logger.info("Successfully recorded Payment ID: {} for Policy ID: {}",
                recordedPayment.getPaymentId(), policyId);

        return new ResponseEntity<>(recordedPayment, HttpStatus.CREATED);
    }

    /**
     * GET /api/payments/policy/123
     * Retrieves all payments for a given policy.
     */
    @GetMapping("/policy/{policyId}")
    public ResponseEntity<List<Payment>> getPaymentsForPolicy(@PathVariable Long policyId) {

        logger.info("Request to retrieve all payments for policy ID: {}", policyId);

        // Call Service
        List<Payment> payments = paymentService.getPaymentsByPolicyId(policyId);

        logger.info("Found {} payments for Policy ID: {}", payments.size(), policyId);

        return ResponseEntity.ok(payments);
    }

    /**
     * GET /api/payments/456
     * Retrieves a single payment by its ID.
     */
    @GetMapping("/{paymentId}")
    public ResponseEntity<Payment> getPaymentById(@PathVariable Long paymentId) {

        logger.info("Request to retrieve payment by ID: {}", paymentId);

        // Call Service
        Payment payment = paymentService.getPaymentById(paymentId);

        logger.info("Retrieved Payment ID: {}", paymentId);

        return ResponseEntity.ok(payment);
    }

    /**
     * PATCH /api/payments/456/status
     * Updates the status of an existing payment.
     * Request Body: {"newStatus": "FAILED"}
     */
    @PatchMapping("/{paymentId}/status")
    public ResponseEntity<Payment> updatePaymentStatus(
            @PathVariable Long paymentId,
            @RequestBody Map<String, String> statusUpdate) {

        String statusString = statusUpdate.get("newStatus");
        logger.info("Attempting to update status for Payment ID: {} to: {}", paymentId, statusString);

        PaymentStatus newStatus = PaymentStatus.valueOf(statusString.toUpperCase());

        // Call Service
        Payment updatedPayment = paymentService.updatePaymentStatus(paymentId, newStatus);

        logger.info("Successfully updated Payment ID: {} to status: {}",
                updatedPayment.getPaymentId(), updatedPayment.getPaymentStatus());

        return ResponseEntity.ok(updatedPayment);
    }
}