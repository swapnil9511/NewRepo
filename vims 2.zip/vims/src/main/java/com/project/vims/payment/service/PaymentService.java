package com.project.vims.payment.service;

import com.project.vims.policy.entity.Policy;
import com.project.vims.policy.repo.PolicyRepo;
import com.project.vims.payment.entity.Payment;
import com.project.vims.payment.entity.Payment.PaymentStatus;
import com.project.vims.payment.repo.PaymentRepo;
import com.project.vims.policy.service.PolicyService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

// SLF4J Imports
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class PaymentService {

    // 💡 Logger for the Service
    private static final Logger logger = LoggerFactory.getLogger(PaymentService.class);

    @Autowired
    private PaymentRepo paymentRepo;

    @Autowired
    private PolicyRepo policyRepo;

    @Autowired
    private PolicyService policyService;

    /** Record a new payment for a policy */
    @Transactional
    public Payment recordPayment(Long policyId, Payment payment) {
        logger.debug("Starting transaction to record payment for policyId: {}", policyId);

        // 1. Find the associated policy
        Policy policy = policyRepo.findById(policyId)
                .orElseThrow(() -> {
                    logger.warn("Policy not found with ID: {}", policyId);
                    return new RuntimeException("Policy not found with ID: " + policyId);
                });
        logger.debug("Found Policy: {}", policy.getPolicyId());

        // 2. Set the relationship and initial status
        payment.setPolicy(policy);
        if (payment.getPaymentStatus() == null) {
            payment.setPaymentStatus(PaymentStatus.SUCCESS);
            logger.debug("Payment status was null, defaulted to SUCCESS.");
        }

        // 3. Save the payment
        Payment savedPayment = paymentRepo.save(payment);
        logger.info("Payment saved with ID: {} and Status: {}", savedPayment.getPaymentId(), savedPayment.getPaymentStatus());

        // 4. BUSINESS LOGIC: Update Policy Status if payment is SUCCESSFUL
        if (savedPayment.getPaymentStatus() == PaymentStatus.SUCCESS) {
            logger.info("Successful payment detected. Activating Policy ID: {}", policyId);
            // If a successful payment is made, ensure the policy is ACTIVE
            policyService.updatePolicyStatus(policyId, Policy.PolicyStatus.ACTIVE);
            logger.info("Policy ID: {} status updated to ACTIVE.", policyId);
        } else {
            logger.info("Payment was {}, no policy status update required.", savedPayment.getPaymentStatus());
        }

        return savedPayment;
    }

    /** Get all payments for a specific policy */
    public List<Payment> getPaymentsByPolicyId(Long policyId) {
        logger.debug("Fetching all payments for policyId: {}", policyId);
        List<Payment> payments = paymentRepo.findByPolicy_PolicyId(policyId);
        logger.debug("Retrieved {} payments for policyId: {}", payments.size(), policyId);
        return payments;
    }

    /** Get a single payment by ID */
    public Payment getPaymentById(Long paymentId) {
        logger.debug("Attempting to find payment by ID: {}", paymentId);
        return paymentRepo.findById(paymentId)
                .orElseThrow(() -> {
                    logger.warn("Payment not found with ID: {}", paymentId);
                    return new RuntimeException("Payment not found with ID: " + paymentId);
                });
    }

    /** Update payment status (e.g., from PENDING to SUCCESS/FAILED) */
    @Transactional
    public Payment updatePaymentStatus(Long paymentId, PaymentStatus newStatus) {
        logger.info("Updating status for payment ID: {} to: {}", paymentId, newStatus);

        Payment existingPayment = getPaymentById(paymentId);
        logger.debug("Found payment with current status: {}", existingPayment.getPaymentStatus());

        if (newStatus != null) {
            existingPayment.setPaymentStatus(newStatus);
            logger.debug("Payment ID: {} status changed to {}.", paymentId, newStatus);
        } else {
            logger.warn("Attempted to update Payment ID: {} with a null status. Status remains {}.",
                    paymentId, existingPayment.getPaymentStatus());
        }

        Payment updatedPayment = paymentRepo.save(existingPayment);
        logger.info("Payment ID: {} successfully saved with new status: {}",
                updatedPayment.getPaymentId(), updatedPayment.getPaymentStatus());

        return updatedPayment;
    }
}