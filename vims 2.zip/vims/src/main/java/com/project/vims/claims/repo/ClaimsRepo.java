package com.project.vims.claims.repo;

import com.project.vims.claims.entity.Claims;
import com.project.vims.policy.entity.Policy;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ClaimsRepo extends JpaRepository<Claims,Long> {

    public List<Claims> findByPolicy(Policy policy);
}
