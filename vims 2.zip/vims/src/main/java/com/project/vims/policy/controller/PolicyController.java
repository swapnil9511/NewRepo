package com.project.vims.policy.controller;


import com.project.vims.policy.entity.Policy;
import com.project.vims.policy.service.PolicyService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

// SLF4J Imports
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@RestController
@RequestMapping("/api/policies")
public class PolicyController {

    private static final Logger logger = LoggerFactory.getLogger(PolicyController.class);

    @Autowired
    PolicyService policyService;


    //  Create new policy
    @PostMapping
    public ResponseEntity<Policy> createPolicy( @RequestParam Long currentUserId, // 💡 NEW: User performing the action
                                                @RequestParam Long policyholderId,
                                                @RequestParam Long vehicleId,
                                                @Valid @RequestBody Policy policy) {
        logger.info("Received POST request from user {} to create a new policy...", currentUserId);

        // Pass currentUserId to the service for authorization
        Policy policyData = policyService.createPolicy(currentUserId, policyholderId, vehicleId, policy);

        logger.info("Policy successfully created with ID: {}", policyData.getPolicyId());
        return new ResponseEntity<>(policyData, HttpStatus.CREATED);
    }

    //  Get all policies (No auth check needed)
    @GetMapping
    public ResponseEntity<List<Policy>> getAllPolicies() {
        logger.info("Received GET request to fetch all policies.");

        List<Policy> policies = policyService.getAllPolicies();

        logger.info("Returning {} policies.", policies.size());
        return ResponseEntity.ok(policies);
    }

    //  Get single policy (No auth check needed)
    @GetMapping("/{id}")
    public ResponseEntity<Policy> getPolicyById( @PathVariable Long id) {
        logger.info("Received GET request to fetch policy with ID: {}", id);

        Policy policy = policyService.getPolicyById(id);

        logger.info("Successfully fetched policy with ID: {}", id);
        return ResponseEntity.ok(policy);
    }

    //  Update existing policy
    @PutMapping("/{id}")
    public ResponseEntity<Policy> updatePolicy(@RequestParam Long currentUserId, // 💡 NEW: User performing the action
                                               @PathVariable Long id,
                                               @Valid @RequestBody Policy policy) {
        logger.info("Received PUT request from user {} to update policy with ID: {}", currentUserId, id);

        // Pass currentUserId to the service for authorization
        Policy updatedPolicy = policyService.updatePolicy(currentUserId, id, policy);

        logger.info("Policy ID: {} successfully updated.", id);
        return ResponseEntity.ok(updatedPolicy);
    }

    //  Delete policy
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePolicy(@RequestParam Long currentUserId, // 💡 NEW: User performing the action
                                             @PathVariable Long id) {
        logger.warn("Received DELETE request from user {} to delete policy with ID: {}", currentUserId, id);

        // Pass currentUserId to the service for authorization
        policyService.deletePolicy(currentUserId, id);

        logger.info("Policy ID: {} successfully deleted.", id);
        return ResponseEntity.noContent().build();
    }


}