package com.project.vims.support.service;

import com.project.vims.support.entity.SupportTicket;
import com.project.vims.support.repo.SupportRepo;
import com.project.vims.user.entity.User;
import com.project.vims.user.repo.UserRepo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;

@Service
public class SupportService {

    @Autowired
    SupportRepo supportRepo;

    @Autowired
    UserRepo userRepo;

    private static final Logger logger = LoggerFactory.getLogger(SupportService.class);

//----------------------------------------------------------------------------------------------------

    // create Ticket

    public ResponseEntity<Map<String,Object>> createTicket(SupportTicket supportTicket) {

        Map<String,Object> response = new HashMap<>();

        User user = userRepo.findById(supportTicket.getUser().getUserId()).orElse(null);
        if(user == null){
            response.put("message","user not found");
            logger.warn("user not found");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }

        //setting the Date and Status by backend
        supportTicket.setCreatedDate(LocalDate.now());
        supportTicket.setTicketStatus(SupportTicket.TicketStatus.OPEN);
        response.put("message","ticket generated successfully");
        SupportTicket supportTicketDB = supportRepo.save(supportTicket);
        response.put("data",supportTicketDB);

        logger.info("Ticket Generated Successfully ",supportTicket.getTicketId()+supportTicketDB.getIssueDescription());
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

//----------------------------------------------------------------------------------------------------

    // get Ticket by Id
    public ResponseEntity<Map<String,Object>> getTicketDetails(Long ticketId) {

        //Map creation
        Map<String,Object> response = new HashMap<>();

        //check ticketId is exist or not
       //Optional<SupportTicket> ticketData = supportRepo.findById(ticketId);
        SupportTicket supportTicketData = supportRepo.findById(ticketId).orElse(null);

        if(supportTicketData == null){
            response.put("message","ticketId Not Found");
            logger.warn("ticketId Not Found "+ticketId);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }

        //if Data TicketId is Found Sending the Data
        response.put("message","ticketId Found");
        response.put("data",supportTicketData);

        logger.info("Getting Data for ticketId "+ticketId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

//----------------------------------------------------------------------------------------------------------------------

    // get All Tickets by UserId

    public ResponseEntity<Map<String,Object>> getAllTicket(Long userId) {

        Map<String,Object> response = new HashMap<>();

        //check userid is exist or not
        // we not use Optional class instead use .orElse(null)
        User user = userRepo.findById(userId).orElse(null);
        if(user == null){

            response.put("message","UserId Not Found");
            logger.warn("UserId Not Found "+userId);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }

        //if userId found get all Tickets
        List<SupportTicket> tickets = supportRepo.findByUser(user);
        if(tickets.isEmpty()){
            response.put("message","not ticket found");
            logger.info("User with userId "+userId+" Not have Tickets");
            return ResponseEntity.status(HttpStatus.OK).body(response);     //No ticket created by user so HttpStatus.ok
        }

        response.put("message","UserId and Tickets Found");
        response.put("data",tickets);

        logger.info("UserId "+userId+" and Tickets Found = "+tickets.size());
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }


//-----------------------------------------------------------------------------------------------------

    //resolve Tickets

    public ResponseEntity<Map<String,Object>> resolveTicket(Long ticketId,Long actingUserId) {

        Map<String,Object> response = new HashMap<>();

        // 1. Check if the User exists and retrieve their role
        User actingUser = userRepo.findById(actingUserId).orElse(null);
        if(actingUser == null){
            response.put("message","Authentication failed: User not found.");
            logger.warn("Authentication failed: User ID " + actingUserId + " not found.");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
        }

        // 2. Role-Based Access Check: Only ADMIN can resolve tickets
        if (actingUser.getRole() != User.Role.ADMIN) {
            response.put("message","Access Denied. Only users with the ADMIN role can resolve tickets.");
            logger.warn("Access Denied: User " + actingUserId + " with role " + actingUser.getRole() + " attempted to resolve ticket " + ticketId);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(response); // HTTP 403 Forbidden
        }


        //Check TicketId is Present or Not
        SupportTicket supportTicketData = supportRepo.findById(ticketId).orElse(null);

        if(supportTicketData == null){
            response.put("message","ticketId Not Found");
            logger.warn("ticketId Not Found "+ticketId);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }

        //if Data TicketId is Found Sending the Data
        supportTicketData.setTicketStatus(SupportTicket.TicketStatus.RESOLVED);

        //Save or update in Database
        SupportTicket updatedSupportTicket = supportRepo.save(supportTicketData);
        response.put("message","ticketId Found and Status Resolve Successfully");
        response.put("data",updatedSupportTicket);

        logger.info("Ticket Resolve Successfully for TicketId"+ticketId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

//-----------------------------------------------------------------------------------------------------

    public ResponseEntity<Map<String,Object>> getAllTicketsForAdmin() {

        Map<String,Object> response = new HashMap<>();

        // Fetch all tickets from the repository
        List<SupportTicket> allTickets = supportRepo.findAll();

        if(allTickets.isEmpty()){
            response.put("message","No tickets found in the system.");
            logger.info("No tickets found in the system for admin view.");
            return ResponseEntity.status(HttpStatus.OK).body(response);
        }

        response.put("message","All tickets found.");
        response.put("data",allTickets);

        logger.info("All tickets found for admin view. Total: "+allTickets.size());
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

//----------------------------------------------------------------------------------------------------------------------

}