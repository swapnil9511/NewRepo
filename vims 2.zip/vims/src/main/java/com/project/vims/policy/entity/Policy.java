package com.project.vims.policy.entity;



import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import com.project.vims.claims.entity.Claims;
import com.project.vims.payment.entity.Payment;
import com.project.vims.user.entity.User;
import com.project.vims.vehicle.entity.Vehicle;

@Entity
@Table(name = "policy")
public class Policy {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long policyId;

    @Column(unique = true,nullable = false)
    private String policyNumber;

    @ManyToOne
    @JoinColumn(name = "policyholder_id")
    @JsonIgnoreProperties({"policies","handledClaims","tickets","vehicles"})
    private User policyholder;

    @ManyToOne
    @JoinColumn(name = "vehicle_id")
    @JsonIgnoreProperties("owner")
    private Vehicle vehicle;

    @NotNull
    private BigDecimal coverageAmount;

    @Enumerated(EnumType.STRING)
    private PolicyStatus policyStatus;

    private LocalDate createdDate = LocalDate.now();

    @OneToMany(mappedBy = "policy", cascade = CascadeType.ALL)
    private List<Claims> claims;

    @OneToMany(mappedBy = "policy", cascade = CascadeType.ALL)
    private List<Payment> payments;

    public enum PolicyStatus {
        ACTIVE, INACTIVE, EXPIRED
    }

    // Getters and Setters
    public Long getPolicyId() {
        return policyId;
    }
    public void setPolicyId(Long policyId) {
        this.policyId = policyId;
    }
    public String getPolicyNumber() {
        return policyNumber;
    }
    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }
    public User getPolicyholder() {
        return policyholder;
    }
    public void setPolicyholder(User policyholder) {
        this.policyholder = policyholder;
    }
    public Vehicle getVehicle() {
        return vehicle;
    }
    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }
    public BigDecimal getCoverageAmount() {
        return coverageAmount;
    }
    public void setCoverageAmount(BigDecimal coverageAmount) {
        this.coverageAmount = coverageAmount;
    }
    public PolicyStatus getPolicyStatus() {
        return policyStatus;
    }
    public void setPolicyStatus(PolicyStatus policyStatus) {
        this.policyStatus = policyStatus;
    }
    public LocalDate getCreatedDate() {
        return createdDate;
    }
    public void setCreatedDate(LocalDate createdDate) {
        this.createdDate = createdDate;
    }
    public List<Claims> getClaims() {
        return claims;
    }
    public void setClaims(List<Claims> claims) {
        this.claims = claims;
    }
    public List<Payment> getPayments() {
        return payments;
    }
    public void setPayments(List<Payment> payments) {
        this.payments = payments;
    }
	public Policy(Long policyId, String policyNumber, User policyholder, Vehicle vehicle,
			@NotNull BigDecimal coverageAmount, PolicyStatus policyStatus, LocalDate createdDate, List<Claims> claims,
			List<Payment> payments) {
		super();
		this.policyId = policyId;
		this.policyNumber = policyNumber;
		this.policyholder = policyholder;
		this.vehicle = vehicle;
		this.coverageAmount = coverageAmount;
		this.policyStatus = policyStatus;
		this.createdDate = createdDate;
		this.claims = claims;
		this.payments = payments;
	}
	public Policy() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Policy(String policyNumber, User policyholder, Vehicle vehicle, @NotNull BigDecimal coverageAmount,
			PolicyStatus policyStatus, LocalDate createdDate, List<Claims> claims, List<Payment> payments) {
		super();
		this.policyNumber = policyNumber;
		this.policyholder = policyholder;
		this.vehicle = vehicle;
		this.coverageAmount = coverageAmount;
		this.policyStatus = policyStatus;
		this.createdDate = createdDate;
		this.claims = claims;
		this.payments = payments;
	}
	@Override
	public String toString() {
		return "Policy [policyId=" + policyId + ", policyNumber=" + policyNumber + ", policyholder=" + policyholder
				+ ", vehicle=" + vehicle + ", coverageAmount=" + coverageAmount + ", policyStatus=" + policyStatus
				+ ", createdDate=" + createdDate + ", claims=" + claims + ", payments=" + payments + "]";
	}
    
    
}