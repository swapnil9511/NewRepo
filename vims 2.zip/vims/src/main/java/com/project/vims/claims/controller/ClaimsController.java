package com.project.vims.claims.controller;

import com.project.vims.claims.entity.Claims;
import com.project.vims.claims.service.ClaimsService;
import com.project.vims.policy.entity.Policy;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/Claims")
public class ClaimsController {

    private static final Logger logger = LoggerFactory.getLogger(ClaimsController.class);

    @Autowired
    ClaimsService claimsService;

//    @GetMapping("/check")
//    public String checkContoller(){
//        return "controller is ok ";
//    }

    @PostMapping("/submitClaim")
    public ResponseEntity<Map<String, Object>>  submitClaim(@Valid@RequestBody Claims claims){
        logger.info("Received request at /submitClaim endpoint.");
       return claimsService.submitClaim(claims);
    }

    @GetMapping("/getClaimDetails/{claimId}")
    public ResponseEntity<Map<String, Object>> getClaimDetails(@Valid @PathVariable Long claimId){
        logger.info("Received request at /getClaimDetails/{} endpoint.", claimId);
       return claimsService.getClaimDetails(claimId);
    }

   @PutMapping("/updateClaimStatus")
    public ResponseEntity<Map<String, Object>>  updateClaimStatus(@Valid@RequestBody Claims claims){
       logger.info("Received request at /updateClaimStatus endpoint for claim ID: {}", claims != null ? claims.getClaimId() : "null");
        return claimsService.updateClaimStatus(claims);
    }

    @GetMapping("/getAllClaimsByPolicy/{policy_id}")
    public ResponseEntity<Map<String, Object>> getAllClaimsByPolicy(@Valid @PathVariable Long policy_id){
        logger.info("Received request at /getAllClaimsByPolicy/{} endpoint.", policy_id);
        return claimsService.getAllClaimsByPolicy(policy_id);
    }

}
