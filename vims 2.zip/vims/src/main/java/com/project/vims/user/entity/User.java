package com.project.vims.user.entity;


import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

import java.util.Base64;
import java.util.List;

import com.project.vims.claims.entity.Claims;
import com.project.vims.policy.entity.Policy;
import com.project.vims.support.entity.SupportTicket;
import com.project.vims.vehicle.entity.Vehicle;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long userId;

    @NotBlank(message = "Username is required")
    @Column(unique = true)
    private String username;

    @NotBlank(message = "Password cannot be empty")
    private String password;

    @Enumerated(EnumType.STRING)
    private Role role;

    @Email(message = "Invalid email format")
    private String email;

    // Relationships
    @OneToMany(mappedBy = "policyholder", cascade = CascadeType.ALL)
    private List<Policy> policies;

    @OneToMany(mappedBy = "adjuster", cascade = CascadeType.ALL)
    private List<Claims> handledClaims;

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
    private List<SupportTicket> tickets;

    @OneToMany(mappedBy = "owner", cascade = CascadeType.ALL)
    private List<Vehicle> vehicles;

    public enum Role {
        ADMIN, AGENT, CLAIM_ADJUSTER, POLICYHOLDER
    }

    // Getters and Setters
    public Long getUserId() {
        return userId;
    }
    public void setUserId(Long userId) {
        this.userId = userId;
    }
    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    public String getPassword() {
        return password;
    }
public void setPassword(String password) {
    this.password = Base64.getEncoder().encodeToString(password.getBytes());
}
    public Role getRole() {
        return role;
    }
    public void setRole(Role role) {
        this.role = role;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public List<Policy> getPolicies() {
        return policies;
    }
    public void setPolicies(List<Policy> policies) {
        this.policies = policies;
    }
    public List<Claims> getHandledClaims() {
        return handledClaims;
    }
    public void setHandledClaims(List<Claims> handledClaims) {
        this.handledClaims = handledClaims;
    }
    public List<SupportTicket> getTickets() {
        return tickets;
    }
    public void setTickets(List<SupportTicket> tickets) {
        this.tickets = tickets;
    }
    public List<Vehicle> getVehicles() {
        return vehicles;
    }
    public void setVehicles(List<Vehicle> vehicles) {
        this.vehicles = vehicles;
    }
    public User(Long userId, @NotBlank(message = "Username is required") String username,
                @NotBlank(message = "Password cannot be empty") String password, Role role,
                @Email(message = "Invalid email format") String email, List<Policy> policies, List<Claims> handledClaims,
                List<SupportTicket> tickets, List<Vehicle> vehicles) {
        super();
        this.userId = userId;
        this.username = username;
        this.password = password;
        this.role = role;
        this.email = email;
        this.policies = policies;
        this.handledClaims = handledClaims;
        this.tickets = tickets;
        this.vehicles = vehicles;
    }
    public User(@NotBlank(message = "Username is required") String username,
                @NotBlank(message = "Password cannot be empty") String password, Role role,
                @Email(message = "Invalid email format") String email, List<Policy> policies, List<Claims> handledClaims,
                List<SupportTicket> tickets, List<Vehicle> vehicles) {
        super();
        this.username = username;
        this.password = password;
        this.role = role;
        this.email = email;
        this.policies = policies;
        this.handledClaims = handledClaims;
        this.tickets = tickets;
        this.vehicles = vehicles;
    }
    public User() {
        super();
        // TODO Auto-generated constructor stub
    }
    @Override
    public String toString() {
        return "User [userId=" + userId + ", username=" + username + ", password=" + password + ", role=" + role
                + ", email=" + email + ", policies=" + policies + ", handledClaims=" + handledClaims + ", tickets="
                + tickets + ", vehicles=" + vehicles + "]";
    }


}