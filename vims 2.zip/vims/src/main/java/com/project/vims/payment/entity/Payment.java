package com.project.vims.payment.entity;



import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.project.vims.user.entity.User;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.LocalDate;

import com.project.vims.policy.entity.Policy;

@Entity
@Table(name = "payment")
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long paymentId;

    @ManyToOne
    @JoinColumn(name = "policy_id")
    @JsonIgnoreProperties({"claims","payments"})
    private Policy policy;


    @ManyToOne
    @JoinColumn(name = "user_id") // This will be the policyholder who made the payment
    @JsonIgnoreProperties({"policies","handledClaims","tickets","vehicles"})
    private User policyholder;

    @NotNull
    private BigDecimal amount;

    private LocalDate paymentDate = LocalDate.now();

    @Enumerated(EnumType.STRING)
    private PaymentStatus paymentStatus;

    public enum PaymentStatus {
        SUCCESS, PENDING, FAILED
    }

    // Getters and Setters
    public Long getPaymentId() {
        return paymentId;
    }
    public void setPaymentId(Long paymentId) {
        this.paymentId = paymentId;
    }
    public Policy getPolicy() {
        return policy;
    }
    public void setPolicy(Policy policy) {
        this.policy = policy;
    }
    public BigDecimal getAmount() {
        return amount;
    }
    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }
    public LocalDate getPaymentDate() {
        return paymentDate;
    }
    public void setPaymentDate(LocalDate paymentDate) {
        this.paymentDate = paymentDate;
    }
    public PaymentStatus getPaymentStatus() {
        return paymentStatus;
    }
    public void setPaymentStatus(PaymentStatus paymentStatus) {
        this.paymentStatus = paymentStatus;
    }
	public Payment(Long paymentId, Policy policy, @NotNull BigDecimal amount, LocalDate paymentDate,
			PaymentStatus paymentStatus) {
		super();
		this.paymentId = paymentId;
		this.policy = policy;
		this.amount = amount;
		this.paymentDate = paymentDate;
		this.paymentStatus = paymentStatus;
	}
	public Payment(Policy policy, @NotNull BigDecimal amount, LocalDate paymentDate, PaymentStatus paymentStatus) {
		super();
		this.policy = policy;
		this.amount = amount;
		this.paymentDate = paymentDate;
		this.paymentStatus = paymentStatus;
	}
	public Payment() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Payment [paymentId=" + paymentId + ", policy=" + policy + ", amount=" + amount + ", paymentDate="
				+ paymentDate + ", paymentStatus=" + paymentStatus + "]";
	}
    
    
	
    
    
}