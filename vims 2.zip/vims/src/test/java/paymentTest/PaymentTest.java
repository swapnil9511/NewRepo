package paymentTest;

import com.project.vims.payment.entity.Payment;
import com.project.vims.payment.entity.Payment.PaymentStatus;
import com.project.vims.payment.repo.PaymentRepo;
import com.project.vims.payment.service.PaymentService;
import com.project.vims.policy.entity.Policy;
import com.project.vims.policy.entity.Policy.PolicyStatus;
import com.project.vims.policy.repo.PolicyRepo;
import com.project.vims.policy.service.PolicyService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

// Integrates Mockito with JUnit 5 to enable annotations like @Mock and @InjectMocks
@ExtendWith(MockitoExtension.class)
public class PaymentTest {

    // --- Mocks and Class Under Test ---
    @Mock
    private PaymentRepo paymentRepo;

    @Mock
    private PolicyRepo policyRepo;

    @Mock
    private PolicyService policyService;

    // Inject the mocks into the service instance we are testing
    @InjectMocks
    private PaymentService paymentService;

    // --- Test Data ---
    private Policy policy;
    private Payment payment;
    private final Long policyId = 1L;
    private final Long paymentId = 101L;

    @BeforeEach
    void setUp() {
        // Setup mock Policy object
        policy = new Policy();
        policy.setPolicyId(policyId);
        // We set it to INACTIVE to prove it gets switched to ACTIVE upon successful payment
        policy.setPolicyStatus(PolicyStatus.INACTIVE);

        // Setup mock Payment object
        payment = new Payment();
        payment.setPaymentId(paymentId);
        payment.setAmount(new BigDecimal("100.00"));
        payment.setPaymentDate(LocalDate.now());
        payment.setPolicy(policy);
    }

    // =================================================================
    // 1. Tests for recordPayment(Long policyId, Payment payment)
    // =================================================================

    @Test
    void recordPayment_SuccessfulPayment_PolicyBecomesActive() {
        // ARRANGE
        // 1. Policy exists
        when(policyRepo.findById(policyId)).thenReturn(Optional.of(policy));

        // 2. Payment is saved (and defaults to SUCCESS if null, or is set to SUCCESS)
        payment.setPaymentStatus(PaymentStatus.SUCCESS); // Explicitly set for clarity
        when(paymentRepo.save(any(Payment.class))).thenReturn(payment);

        // ACT
        Payment result = paymentService.recordPayment(policyId, payment);

        // ASSERT
        assertNotNull(result, "The saved payment should not be null.");
        assertEquals(PaymentStatus.SUCCESS, result.getPaymentStatus(), "Payment status should be SUCCESS.");

        // VERIFY BUSINESS LOGIC: policyService.updatePolicyStatus MUST be called once
        verify(policyService, times(1)).updatePolicyStatus(policyId, PolicyStatus.ACTIVE);

        // VERIFY REPOSITORY INTERACTIONS
        verify(policyRepo, times(1)).findById(policyId);
        verify(paymentRepo, times(1)).save(payment);
    }

    @Test
    void recordPayment_PaymentStatusIsNull_DefaultsToSuccessAndActivatesPolicy() {
        // ARRANGE
        when(policyRepo.findById(policyId)).thenReturn(Optional.of(policy));
        payment.setPaymentStatus(null); // The service should set this to SUCCESS

        // Use thenAnswer to simulate the repository returning the object after the service has processed it
        when(paymentRepo.save(any(Payment.class))).thenAnswer(invocation -> {
            // ✅ CORRECTION: The single argument passed to save() is at index 0.
            Payment savedP = invocation.getArgument(0);

            // This logic is mainly to ensure the returned object reflects the status change
            // performed by the service before the final 'save'
            if (savedP.getPaymentStatus() == null) {
                savedP.setPaymentStatus(PaymentStatus.SUCCESS);
            }
            return savedP;
        });

        // ACT
        Payment result = paymentService.recordPayment(policyId, payment);

        // ASSERT
        assertEquals(PaymentStatus.SUCCESS, result.getPaymentStatus(), "Payment status should default to SUCCESS.");

        // VERIFY BUSINESS LOGIC
        verify(policyService, times(1)).updatePolicyStatus(policyId, Policy.PolicyStatus.ACTIVE);
        verify(paymentRepo, times(1)).save(payment);
    }

    @Test
    void recordPayment_PolicyNotFound_ThrowsRuntimeException() {
        // ARRANGE
        when(policyRepo.findById(policyId)).thenReturn(Optional.empty());

        // ACT & ASSERT
        assertThrows(RuntimeException.class, () -> {
            paymentService.recordPayment(policyId, payment);
        }, "Should throw RuntimeException when Policy is not found.");

        // VERIFY NO INTERACTION with save or policy update
        verify(paymentRepo, never()).save(any(Payment.class));
        verify(policyService, never()).updatePolicyStatus(anyLong(), any());
    }

    @Test
    void recordPayment_FailedPayment_PolicyStatusIsNotUpdated() {
        // ARRANGE
        when(policyRepo.findById(policyId)).thenReturn(Optional.of(policy));

        payment.setPaymentStatus(PaymentStatus.FAILED);
        when(paymentRepo.save(any(Payment.class))).thenReturn(payment);

        // ACT
        Payment result = paymentService.recordPayment(policyId, payment);

        // ASSERT
        assertEquals(PaymentStatus.FAILED, result.getPaymentStatus(), "Payment status should be FAILED.");

        // VERIFY BUSINESS LOGIC: policyService.updatePolicyStatus MUST NOT be called
        verify(policyService, never()).updatePolicyStatus(anyLong(), any());
    }

    // =================================================================
    // 2. Tests for getPaymentsByPolicyId(Long policyId)
    // =================================================================

    @Test
    void getPaymentsByPolicyId_ReturnsListOfPayments() {
        // ARRANGE
        Payment payment2 = new Payment();
        List<Payment> expectedPayments = Arrays.asList(payment, payment2);
        when(paymentRepo.findByPolicy_PolicyId(policyId)).thenReturn(expectedPayments);

        // ACT
        List<Payment> result = paymentService.getPaymentsByPolicyId(policyId);

        // ASSERT
        assertNotNull(result, "The list of payments should not be null.");
        assertEquals(2, result.size(), "Should return two payments.");

        // VERIFY REPOSITORY INTERACTION
        verify(paymentRepo, times(1)).findByPolicy_PolicyId(policyId);
    }

    // =================================================================
    // 3. Tests for getPaymentById(Long paymentId)
    // =================================================================

    @Test
    void getPaymentById_PaymentFound_ReturnsPayment() {
        // ARRANGE
        when(paymentRepo.findById(paymentId)).thenReturn(Optional.of(payment));

        // ACT
        Payment result = paymentService.getPaymentById(paymentId);

        // ASSERT
        assertNotNull(result, "The payment should be found.");
        assertEquals(paymentId, result.getPaymentId(), "The returned payment ID should match the request ID.");
    }

    @Test
    void getPaymentById_PaymentNotFound_ThrowsRuntimeException() {
        // ARRANGE
        when(paymentRepo.findById(paymentId)).thenReturn(Optional.empty());

        // ACT & ASSERT
        assertThrows(RuntimeException.class, () -> {
            paymentService.getPaymentById(paymentId);
        }, "Should throw RuntimeException when Payment is not found.");
    }

    // =================================================================
    // 4. Tests for updatePaymentStatus(Long paymentId, PaymentStatus newStatus)
    // =================================================================

    @Test
    void updatePaymentStatus_StatusUpdatedSuccessfully() {
        // ARRANGE
        PaymentStatus newStatus = PaymentStatus.PENDING;

        // 1. Stub findById (used internally by getPaymentById)
        when(paymentRepo.findById(paymentId)).thenReturn(Optional.of(payment));

        // 2. Stub save
        when(paymentRepo.save(any(Payment.class))).thenAnswer(invocation -> {
            Payment savedP = invocation.getArgument(0);
            return savedP; // Return the modified object
        });

        // ACT
        Payment result = paymentService.updatePaymentStatus(paymentId, newStatus);

        // ASSERT
        assertEquals(newStatus, result.getPaymentStatus(), "The payment status should be updated to PENDING.");

        // VERIFY REPOSITORY INTERACTION: Capture the argument passed to save for deeper inspection
        verify(paymentRepo).save(argThat(p -> p.getPaymentStatus() == newStatus && p.getPaymentId().equals(paymentId)));
    }

    @Test
    void updatePaymentStatus_NewStatusIsNull_StatusRemainsUnchanged() {
        // ARRANGE
        PaymentStatus originalStatus = PaymentStatus.SUCCESS;
        payment.setPaymentStatus(originalStatus); // Set initial status

        // 1. Stub findById
        when(paymentRepo.findById(paymentId)).thenReturn(Optional.of(payment));

        // 2. Stub save to return the original object
        when(paymentRepo.save(any(Payment.class))).thenReturn(payment);

        // ACT
        Payment result = paymentService.updatePaymentStatus(paymentId, null);

        // ASSERT
        // The original status should still be present in the saved object
        assertEquals(originalStatus, result.getPaymentStatus(), "The status should remain unchanged when newStatus is null.");

        // VERIFY REPOSITORY INTERACTION
        verify(paymentRepo, times(1)).save(payment);
    }
}