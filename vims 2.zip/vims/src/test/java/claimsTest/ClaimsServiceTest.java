package claimsTest;

import com.project.vims.claims.entity.Claims;
import com.project.vims.claims.repo.ClaimsRepo;
import com.project.vims.claims.service.ClaimsService;
import com.project.vims.policy.entity.Policy;
import com.project.vims.policy.repo.PolicyRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ClaimsServiceTest {

    @Mock
    private ClaimsRepo claimsRepo;

    @Mock
    private PolicyRepo policyRepo;

    @InjectMocks
    private ClaimsService claimsService;

    private Policy testPolicy;
    private Claims testClaim;

    @BeforeEach
    void setUp() {
        // Create common test objects to be used in multiple tests
        testPolicy = new Policy();
        testPolicy.setPolicyId(1L);

        testClaim = new Claims();
        testClaim.setClaimId(101L);
        testClaim.setPolicy(testPolicy);
        testClaim.setClaimAmount(new BigDecimal("1000.00"));
        testClaim.setClaimStatus(Claims.ClaimStatus.PENDING);
        testClaim.setClaimDate(LocalDate.now());
    }

    // --- Tests for submitClaim ---

    @Test
    void testSubmitClaim_Success() {
        // Arrange
        Claims inputClaim = new Claims();
        inputClaim.setPolicy(testPolicy);
        inputClaim.setClaimAmount(new BigDecimal("500.00"));

        when(policyRepo.findById(1L)).thenReturn(Optional.of(testPolicy));
        when(claimsRepo.save(any(Claims.class))).thenReturn(testClaim);

        // Act
        ResponseEntity<Map<String, Object>> response = claimsService.submitClaim(inputClaim);

        // Assert
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals("Claim submitted successfully", response.getBody().get("message"));
        verify(claimsRepo, times(1)).save(any(Claims.class));
    }

    @Test
    void testSubmitClaim_PolicyNotFound() {
        // Arrange
        Claims inputClaim = new Claims();
        inputClaim.setPolicy(testPolicy);
        when(policyRepo.findById(1L)).thenReturn(Optional.empty());

        // Act
        ResponseEntity<Map<String, Object>> response = claimsService.submitClaim(inputClaim);

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Policy with ID 1 not found.", response.getBody().get("message"));
        verify(claimsRepo, never()).save(any());
    }

    // --- Tests for getClaimDetails ---

    @Test
    void testGetClaimDetails_Success() {
        // Arrange
        when(claimsRepo.findById(101L)).thenReturn(Optional.of(testClaim));

        // Act
        ResponseEntity<Map<String, Object>> response = claimsService.getClaimDetails(101L);

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(testClaim, response.getBody().get("data"));
    }

    @Test
    void testGetClaimDetails_NotFound() {
        // Arrange
        when(claimsRepo.findById(99L)).thenReturn(Optional.empty());

        // Act
        ResponseEntity<Map<String, Object>> response = claimsService.getClaimDetails(99L);

        // Assert
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertEquals("Claim with ID 99 not found.", response.getBody().get("message"));
    }

    // --- Tests for updateClaimStatus ---

    @Test
    void testUpdateClaimStatus_Success() {
        // Arrange
        Claims updateData = new Claims();
        updateData.setClaimId(101L);
        updateData.setClaimStatus(Claims.ClaimStatus.APPROVED);

        when(claimsRepo.findById(101L)).thenReturn(Optional.of(testClaim));
        when(claimsRepo.save(any(Claims.class))).thenAnswer(invocation -> invocation.getArgument(0));


        // Act
        ResponseEntity<Map<String, Object>> response = claimsService.updateClaimStatus(updateData);

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        Claims responseData = (Claims) response.getBody().get("data");
        assertEquals(Claims.ClaimStatus.APPROVED, responseData.getClaimStatus());
    }

    @Test
    void testUpdateClaimStatus_NotFound() {
        // Arrange
        Claims updateData = new Claims();
        updateData.setClaimId(99L);
        when(claimsRepo.findById(99L)).thenReturn(Optional.empty());

        // Act
        ResponseEntity<Map<String, Object>> response = claimsService.updateClaimStatus(updateData);

        // Assert
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        verify(claimsRepo, never()).save(any());
    }

    // --- Tests for getAllClaimsByPolicy ---

    @Test
    void testGetAllClaimsByPolicy_Success() {
        // Arrange
        List<Claims> claimsList = Collections.singletonList(testClaim);
        when(policyRepo.findById(1L)).thenReturn(Optional.of(testPolicy));
        when(claimsRepo.findByPolicy(testPolicy)).thenReturn(claimsList);

        // Act
        ResponseEntity<Map<String, Object>> response = claimsService.getAllClaimsByPolicy(1L);

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(claimsList, response.getBody().get("data"));
    }

    @Test
    void testGetAllClaimsByPolicy_PolicyNotFound() {
        // Arrange
        when(policyRepo.findById(99L)).thenReturn(Optional.empty());

        // Act
        ResponseEntity<Map<String, Object>> response = claimsService.getAllClaimsByPolicy(99L);

        // Assert
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        verify(claimsRepo, never()).findByPolicy(any());
    }
}
