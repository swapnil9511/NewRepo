package supportTest;

import com.project.vims.support.entity.SupportTicket;
import com.project.vims.support.repo.SupportRepo;
import com.project.vims.support.service.SupportService;
import com.project.vims.user.entity.User;
import com.project.vims.user.repo.UserRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.time.LocalDate;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SupportServiceTest {

    // Mocking the dependencies
    @Mock
    private SupportRepo supportRepo;

    @Mock
    private UserRepo userRepo;

    // Injecting the mocks into the service class being tested
    @InjectMocks
    private SupportService supportService;

    // Test Data Setup
    private User regularUser;
    private User adminUser;
    private SupportTicket openTicket;

    @BeforeEach
    void setUp() {
        // Setup Regular User (Role.POLICYHOLDER - mapping to User.Role from your code)
        regularUser = new User();
        regularUser.setUserId(10L);
        // Note: I'm using a common role like POLICYHOLDER as 'USER' is not defined in your User class enum.
        // Assuming POLICYHOLDER or any other non-ADMIN role is sufficient for ticket creation.
        // For resolveTicket testing, this user will fail the ADMIN check.
        regularUser.setRole(User.Role.POLICYHOLDER);

        // Setup Admin User (Role.ADMIN)
        adminUser = new User();
        adminUser.setUserId(20L);
        adminUser.setRole(User.Role.ADMIN);

        // Setup Ticket for testing (User must be set for createTicket to work)
        openTicket = new SupportTicket();
        openTicket.setUser(regularUser); // User with ID 10L
        openTicket.setIssueDescription("My vehicle registration details are incorrect.");
    }

    // ------------------------------------ createTicket Tests ------------------------------------

    @Test
    @DisplayName("createTicket: Success - New ticket created with OPEN status and current date")
    void createTicket_Success() {
        // Arrange
        when(userRepo.findById(10L)).thenReturn(Optional.of(regularUser));
        when(supportRepo.save(any(SupportTicket.class))).thenAnswer(invocation -> {
            SupportTicket savedTicket = invocation.getArgument(0);
            savedTicket.setTicketId(200L); // Simulate ID generation
            return savedTicket;
        });

        // Act
        ResponseEntity<Map<String, Object>> response = supportService.createTicket(openTicket);

        // Assert
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals("ticket generated successfully", response.getBody().get("message"));

        SupportTicket returnedTicket = (SupportTicket) response.getBody().get("data");
        assertEquals(SupportTicket.TicketStatus.OPEN, returnedTicket.getTicketStatus(), "Status must be set to OPEN by the service.");
        assertEquals(LocalDate.now(), returnedTicket.getCreatedDate(), "Creation date must be set to today.");

        verify(supportRepo, times(1)).save(any(SupportTicket.class));
    }

    @Test
    @DisplayName("createTicket: Failure - User creating ticket not found")
    void createTicket_UserNotFound() {
        // Arrange
        openTicket.getUser().setUserId(999L);
        when(userRepo.findById(999L)).thenReturn(Optional.empty());

        // Act
        ResponseEntity<Map<String, Object>> response = supportService.createTicket(openTicket);

        // Assert
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertEquals("user not found", response.getBody().get("message"));

        verify(supportRepo, never()).save(any()); // Ensure save is not called
    }

    // ------------------------------------ resolveTicket Tests ------------------------------------

    @Test
    @DisplayName("resolveTicket: Success - Admin successfully resolves an open ticket")
    void resolveTicket_Success_Admin() {
        // Arrange
        final Long TICKET_ID = 101L;
        openTicket.setTicketId(TICKET_ID);
        openTicket.setTicketStatus(SupportTicket.TicketStatus.OPEN);

        when(userRepo.findById(20L)).thenReturn(Optional.of(adminUser)); // Acting user is ADMIN
        when(supportRepo.findById(TICKET_ID)).thenReturn(Optional.of(openTicket));
        when(supportRepo.save(any(SupportTicket.class))).thenReturn(openTicket);

        // Act
        ResponseEntity<Map<String, Object>> response = supportService.resolveTicket(TICKET_ID, 20L);

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("ticketId Found and Status Resolve Successfully", response.getBody().get("message"));

        SupportTicket updatedTicket = (SupportTicket) response.getBody().get("data");
        assertEquals(SupportTicket.TicketStatus.RESOLVED, updatedTicket.getTicketStatus(), "Ticket status must be RESOLVED.");

        verify(supportRepo, times(1)).save(openTicket);
    }

    @Test
    @DisplayName("resolveTicket: Failure - Non-Admin user attempts to resolve (FORBIDDEN)")
    void resolveTicket_Failure_AccessDenied() {
        // Arrange
        when(userRepo.findById(10L)).thenReturn(Optional.of(regularUser)); // Acting user is POLICYHOLDER

        // Act
        ResponseEntity<Map<String, Object>> response = supportService.resolveTicket(101L, 10L);

        // Assert
        assertEquals(HttpStatus.FORBIDDEN, response.getStatusCode());
        assertEquals("Access Denied. Only users with the ADMIN role can resolve tickets.", response.getBody().get("message"));

        verify(supportRepo, never()).findById(any());
    }

    @Test
    @DisplayName("resolveTicket: Failure - Acting User ID not found (UNAUTHORIZED)")
    void resolveTicket_Failure_ActingUserNotFound() {
        // Arrange
        when(userRepo.findById(999L)).thenReturn(Optional.empty());

        // Act
        ResponseEntity<Map<String, Object>> response = supportService.resolveTicket(101L, 999L);

        // Assert
        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertEquals("Authentication failed: User not found.", response.getBody().get("message"));
    }

    @Test
    @DisplayName("resolveTicket: Failure - Ticket ID not found (NOT_FOUND)")
    void resolveTicket_Failure_TicketNotFound() {
        // Arrange
        final Long NON_EXISTENT_TICKET_ID = 999L;
        when(userRepo.findById(20L)).thenReturn(Optional.of(adminUser));
        when(supportRepo.findById(NON_EXISTENT_TICKET_ID)).thenReturn(Optional.empty());

        // Act
        ResponseEntity<Map<String, Object>> response = supportService.resolveTicket(NON_EXISTENT_TICKET_ID, 20L);

        // Assert
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertEquals("ticketId Not Found", response.getBody().get("message"));

        verify(supportRepo, times(1)).findById(NON_EXISTENT_TICKET_ID);
        verify(supportRepo, never()).save(any());
    }
}