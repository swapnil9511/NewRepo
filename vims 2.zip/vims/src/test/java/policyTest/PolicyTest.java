package policyTest;

import com.project.vims.policy.entity.Policy;
import com.project.vims.policy.repo.PolicyRepo;
import com.project.vims.policy.service.PolicyService;
import com.project.vims.user.entity.User;
import com.project.vims.user.repo.UserRepo;
import com.project.vims.user.service.UserService;
import com.project.vims.vehicle.entity.Vehicle;
import com.project.vims.vehicle.repo.VehicleRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

// Set up Mockito environment for JUnit 5
@ExtendWith(MockitoExtension.class)
public class PolicyTest {

    @Mock
    private PolicyRepo policyRepo;

    @Mock
    private UserRepo userRepo;

    @Mock
    private VehicleRepo vehicleRepo;

    // MOCK THIS to test the authorization check
    @Mock
    private UserService userService;

    // Inject the mocks into the service being tested
    @InjectMocks
    private PolicyService policyService;

    // Test data setup
    private User adminUser;
    private User regularUser;
    private User policyholderUser;
    private Vehicle testVehicle;
    private Policy testPolicy;
    private final Long ADMIN_USER_ID = 1L;
    private final Long REGULAR_USER_ID = 2L;
    private final Long POLICYHOLDER_ID = 3L;

    @BeforeEach
    void setUp() {
        // Mock the Logger to prevent NullPointerException on initialization
        // Note: Actual logging should be tested externally, but this avoids runtime issues.
        // Utility.mockLogger(PolicyService.class, policyService);

        adminUser = new User();
        adminUser.setUserId(ADMIN_USER_ID);
        adminUser.setUsername("admin");
        adminUser.setRole(User.Role.ADMIN);

        regularUser = new User();
        regularUser.setUserId(REGULAR_USER_ID);
        regularUser.setUsername("regular");
        regularUser.setRole(User.Role.POLICYHOLDER); // Not ADMIN

        policyholderUser = new User();
        policyholderUser.setUserId(POLICYHOLDER_ID);
        policyholderUser.setUsername("policyholder");
        policyholderUser.setRole(User.Role.POLICYHOLDER); // The user who owns the policy

        testVehicle = new Vehicle();
        testVehicle.setVehicleId(1L);
        testVehicle.setVehicleModel("Test Model");

        testPolicy = new Policy();
        testPolicy.setPolicyId(101L);
        testPolicy.setPolicyholder(policyholderUser);
        testPolicy.setVehicle(testVehicle);
        testPolicy.setCoverageAmount(new BigDecimal("50000"));
        testPolicy.setPolicyStatus(Policy.PolicyStatus.ACTIVE);
    }

    // -----------------------------------------------------------------------------------------------------------------

    /** Test for createPolicy (Successful) */
    @Test
    void createPolicy_whenAdminAndEntitiesExist_shouldReturnNewPolicy() {
        // Arrange
        when(userService.getUserById(ADMIN_USER_ID)).thenReturn(adminUser);
        when(userRepo.findById(POLICYHOLDER_ID)).thenReturn(Optional.of(policyholderUser));
        when(vehicleRepo.findById(testVehicle.getVehicleId())).thenReturn(Optional.of(testVehicle));

        // FIX: Use thenAnswer to capture and return the policy object
        // after the service has set the policy number and status.
        when(policyRepo.save(any(Policy.class))).thenAnswer(invocation -> {
            Policy policyToSave = invocation.getArgument(0);
            // The service method will modify this 'policyToSave' object
            // by setting its PolicyNumber and Policyholder.
            return policyToSave; // Return the modified object
        });

        // Act
        Policy createdPolicy = policyService.createPolicy(
                ADMIN_USER_ID, POLICYHOLDER_ID, testVehicle.getVehicleId(), new Policy()
        );

        // Assert
        assertNotNull(createdPolicy);
        assertEquals(Policy.PolicyStatus.ACTIVE, createdPolicy.getPolicyStatus());
        assertEquals(policyholderUser, createdPolicy.getPolicyholder());

        // This is the line that was failing because the policyNumber was null:
        // It now passes because thenAnswer returns the object modified by the service.
        assertTrue(createdPolicy.getPolicyNumber().startsWith("POL-"));

        verify(policyRepo, times(1)).save(any(Policy.class));
    }
    /** Test for createPolicy (Authorization Failure - Not Admin) */
    @Test
    void createPolicy_whenNotAdmin_shouldThrowAuthorizationException() {
        // Arrange
        // 1. Authorization mock: Regular user
        when(userService.getUserById(REGULAR_USER_ID)).thenReturn(regularUser);

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            policyService.createPolicy(REGULAR_USER_ID, POLICYHOLDER_ID, testVehicle.getVehicleId(), new Policy());
        });
        assertEquals("Access Denied: Only ADMIN users can create policies.", exception.getMessage());

        // Ensure no interaction with repos if auth failed
        verify(userRepo, never()).findById(any());
        verify(policyRepo, never()).save(any());
    }

    /** Test for createPolicy (Policyholder Not Found) */
    @Test
    void createPolicy_whenPolicyholderNotFound_shouldThrowException() {
        // Arrange
        when(userService.getUserById(ADMIN_USER_ID)).thenReturn(adminUser); // Auth passes
        when(userRepo.findById(anyLong())).thenReturn(Optional.empty());

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            policyService.createPolicy(ADMIN_USER_ID, 99L, testVehicle.getVehicleId(), new Policy());
        });
        assertEquals("Policyholder not found", exception.getMessage());
        verify(policyRepo, never()).save(any());
    }

    /** Test for createPolicy (Vehicle Not Found) */
    @Test
    void createPolicy_whenVehicleNotFound_shouldThrowException() {
        // Arrange
        when(userService.getUserById(ADMIN_USER_ID)).thenReturn(adminUser); // Auth passes
        when(userRepo.findById(POLICYHOLDER_ID)).thenReturn(Optional.of(policyholderUser));
        when(vehicleRepo.findById(anyLong())).thenReturn(Optional.empty());

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            policyService.createPolicy(ADMIN_USER_ID, POLICYHOLDER_ID, 99L, new Policy());
        });
        assertEquals("Vehicle not found", exception.getMessage());
        verify(policyRepo, never()).save(any());
    }

    // -----------------------------------------------------------------------------------------------------------------

    /** Test for getAllPolicies */
    @Test
    void getAllPolicies_whenPoliciesExist_shouldReturnPolicyList() {
        // Arrange
        when(policyRepo.findAll()).thenReturn(Collections.singletonList(testPolicy));

        // Act
        List<Policy> policies = policyService.getAllPolicies();

        // Assert
        assertFalse(policies.isEmpty());
        assertEquals(1, policies.size());
        verify(policyRepo, times(1)).findAll();
    }

    /** Test for getPolicyById (Found) */
    @Test
    void getPolicyById_whenPolicyExists_shouldReturnPolicy() {
        // Arrange
        when(policyRepo.findById(101L)).thenReturn(Optional.of(testPolicy));

        // Act
        Policy foundPolicy = policyService.getPolicyById(101L);

        // Assert
        assertNotNull(foundPolicy);
        assertEquals(101L, foundPolicy.getPolicyId());
    }

    /** Test for getPolicyById (Not Found) */
    @Test
    void getPolicyById_whenPolicyNotFound_shouldThrowException() {
        // Arrange
        when(policyRepo.findById(99L)).thenReturn(Optional.empty());

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> policyService.getPolicyById(99L));
        assertEquals("Policy not found", exception.getMessage());
    }

    // -----------------------------------------------------------------------------------------------------------------

    /** Test for updatePolicy (Successful) */
    @Test
    void updatePolicy_whenAdminAndPolicyExists_shouldReturnUpdatedPolicy() {
        // Arrange
        // 1. Authorization mock: ADMIN user
        when(userService.getUserById(ADMIN_USER_ID)).thenReturn(adminUser);

        // 2. Business logic mocks
        Policy updatedInfo = new Policy();
        updatedInfo.setCoverageAmount(new BigDecimal("75000"));
        updatedInfo.setPolicyStatus(Policy.PolicyStatus.INACTIVE);

        when(policyRepo.findById(101L)).thenReturn(Optional.of(testPolicy));
        when(policyRepo.save(any(Policy.class))).thenAnswer(invocation -> invocation.getArgument(0)); // Return the modified object

        // Act
        Policy result = policyService.updatePolicy(ADMIN_USER_ID, 101L, updatedInfo);

        // Assert
        assertNotNull(result);
        assertEquals(new BigDecimal("75000"), result.getCoverageAmount());
        assertEquals(Policy.PolicyStatus.INACTIVE, result.getPolicyStatus());
        verify(policyRepo, times(1)).save(any(Policy.class));
    }

    /** Test for updatePolicy (Authorization Failure) */
    @Test
    void updatePolicy_whenNotAdmin_shouldThrowAuthorizationException() {
        // Arrange
        when(userService.getUserById(REGULAR_USER_ID)).thenReturn(regularUser);

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            policyService.updatePolicy(REGULAR_USER_ID, 101L, new Policy());
        });
        assertEquals("Access Denied: Only ADMIN users can update policies.", exception.getMessage());
        verify(policyRepo, never()).findById(any());
        verify(policyRepo, never()).save(any());
    }

    /** Test for updatePolicyStatus (Successful) */
    @Test
    void updatePolicyStatus_whenPolicyExists_shouldUpdateStatus() {
        // Arrange
        when(policyRepo.findById(101L)).thenReturn(Optional.of(testPolicy));
        when(policyRepo.save(any(Policy.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // Act
        Policy updatedPolicy = policyService.updatePolicyStatus(101L, Policy.PolicyStatus.EXPIRED);

        // Assert
        assertEquals(Policy.PolicyStatus.EXPIRED, updatedPolicy.getPolicyStatus());
        verify(policyRepo, times(1)).save(any(Policy.class));
    }

    /** Test for updatePolicyStatus (Policy Not Found) */
    @Test
    void updatePolicyStatus_whenPolicyNotFound_shouldThrowException() {
        // Arrange
        when(policyRepo.findById(99L)).thenReturn(Optional.empty());

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            policyService.updatePolicyStatus(99L, Policy.PolicyStatus.ACTIVE);
        });
        assertEquals("Policy not found with ID: 99", exception.getMessage());
        verify(policyRepo, never()).save(any());
    }

    // -----------------------------------------------------------------------------------------------------------------

    /** Test for deletePolicy (Successful) */
    @Test
    void deletePolicy_whenAdminAndPolicyExists_shouldCompleteSuccessfully() {
        // Arrange
        // 1. Authorization mock: ADMIN user
        when(userService.getUserById(ADMIN_USER_ID)).thenReturn(adminUser);

        // 2. Business logic mocks
        when(policyRepo.findById(101L)).thenReturn(Optional.of(testPolicy));
        doNothing().when(policyRepo).delete(testPolicy);

        // Act
        policyService.deletePolicy(ADMIN_USER_ID, 101L);

        // Assert
        verify(policyRepo, times(1)).delete(testPolicy);
    }

    /** Test for deletePolicy (Authorization Failure) */
    @Test
    void deletePolicy_whenNotAdmin_shouldThrowAuthorizationException() {
        // Arrange
        when(userService.getUserById(REGULAR_USER_ID)).thenReturn(regularUser);

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            policyService.deletePolicy(REGULAR_USER_ID, 101L);
        });
        assertEquals("Access Denied: Only ADMIN users can delete policies.", exception.getMessage());
        verify(policyRepo, never()).findById(any());
        verify(policyRepo, never()).delete(any());
    }

    /** Test for deletePolicy (Policy Not Found) */
    @Test
    void deletePolicy_whenPolicyNotFound_shouldThrowException() {
        // Arrange
        when(userService.getUserById(ADMIN_USER_ID)).thenReturn(adminUser); // Auth passes
        when(policyRepo.findById(99L)).thenReturn(Optional.empty());

        // Act & Assert
        assertThrows(RuntimeException.class, () -> policyService.deletePolicy(ADMIN_USER_ID, 99L));
        verify(policyRepo, never()).delete(any());
    }
}