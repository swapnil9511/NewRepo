package userTest;

import com.project.vims.user.entity.User;
import com.project.vims.user.repo.UserRepo;
import com.project.vims.user.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class UserTest {

    @Mock
    private UserRepo userRepo;

    @InjectMocks
    private UserService userService;

    private User testUser;

    @BeforeEach
    void setUp() {
        testUser = new User();
        testUser.setUserId(1L);
        testUser.setUsername("testuser");
        testUser.setPassword("password123");
        testUser.setRole(User.Role.POLICYHOLDER);
        testUser.setEmail("test@example.com");
    }

    // --- Test for registerUser method ---

    @Test
    void registerUser_Success() {

        when(userRepo.findByUsername(testUser.getUsername())).thenReturn(Optional.empty());
        when(userRepo.save(testUser)).thenReturn(testUser);

        User registeredUser = userService.registerUser(testUser);

        assertNotNull(registeredUser, "The registered user should not be null.");
        assertEquals("testuser", registeredUser.getUsername(), "The username should match the input.");

        verify(userRepo, times(1)).findByUsername(testUser.getUsername());
        verify(userRepo, times(1)).save(testUser);
    }

    @Test
    void registerUser_UsernameTaken_ThrowsException() {

        when(userRepo.findByUsername(testUser.getUsername())).thenReturn(Optional.of(testUser));

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            userService.registerUser(testUser);
        }, "Should throw RuntimeException when username is taken.");

        assertEquals("Username testuser is already taken.", exception.getMessage());

        verify(userRepo, times(1)).findByUsername(testUser.getUsername());
        verify(userRepo, never()).save(any(User.class));
    }

    // --- Test for loginUser method ---

    @Test
    void loginUser_Success() {
        // 1. Setup: User found and passwords match.
        when(userRepo.findByUsername("testuser")).thenReturn(Optional.of(testUser));

        // 2. Action
        User loggedInUser = userService.loginUser("testuser", "password123");

        // 3. Check
        assertNotNull(loggedInUser, "Login should succeed and return a user.");
        assertEquals(1L, loggedInUser.getUserId(), "The correct user should be returned.");
    }

    @Test
    void loginUser_InvalidUsername_ThrowsException() {

        when(userRepo.findByUsername("wronguser")).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> {
            userService.loginUser("wronguser", "password123");
        }, "Should throw exception for invalid username.");
    }

    @Test
    void loginUser_InvalidPassword_ThrowsException() {

        when(userRepo.findByUsername("testuser")).thenReturn(Optional.of(testUser));

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            userService.loginUser("testuser", "wrongpassword");
        }, "Should throw exception for invalid password.");

        assertEquals("Invalid username or password.", exception.getMessage());
    }

    // --- Test for logOutUser method ---

    @Test
    void logOutUser_Success() {
        // No fake repo action needed, as this method only returns a string.

        // 1. Action
        String message = userService.logOutUser(10L);

        // 2. Check
        assertEquals("User with ID 10 has been successfully logged out.", message);

        // 3. Verify: Check that no repo methods were called.
        verifyNoInteractions(userRepo);
    }

    // --- Test for getUserById method ---

    @Test
    void getUserById_Found_ReturnsUser() {

        when(userRepo.findById(1L)).thenReturn(Optional.of(testUser));

        User foundUser = userService.getUserById(1L);

        assertNotNull(foundUser, "User should be found.");
        assertEquals(1L, foundUser.getUserId());
    }

    @Test
    void getUserById_NotFound_ReturnsNull() {

        when(userRepo.findById(2L)).thenReturn(Optional.empty());

        User foundUser = userService.getUserById(2L);

        assertNull(foundUser, "User should not be found, so it should return null.");
    }
}