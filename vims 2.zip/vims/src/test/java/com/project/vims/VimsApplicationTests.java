package com.project.vims;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VimsApplicationTests {

	@Test
	void contextLoads() {
	}

}
